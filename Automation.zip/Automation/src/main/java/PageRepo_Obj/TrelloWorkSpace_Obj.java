package PageRepo_Obj;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TrelloWorkSpace_Obj {
	WebDriver driver;
	
	@FindBy (xpath = "//li[@data-testid = 'create-board-tile']")
	WebElement NewBoard;
	
	@FindBy (xpath = "//div[contains(text(),'Board title')]/following-sibling::input")
	WebElement NewBoardTitle;
	
	@FindBy (xpath = "//label[contains(text(),'Visibility')]/following-sibling::button")
	WebElement CreateNewBoardBtn;
	
	@FindBy (xpath = "//span[contains(text(),'Add another list')]")
	WebElement AddList;
	
	@FindBy (xpath = "//input[@class='list-name-input']")
	WebElement ListTitle;
	
	@FindBy (xpath = "//input[@value='Add list']")
	WebElement AddListBtn;
	
	@FindBy (xpath = "//div/textarea[@aria-label='List A']/parent::div/following-sibling::div[2]/a/span[2]")
	WebElement Add_A_Card;
	
	@FindBy (xpath = "//div/textarea[@aria-label='List A']/parent::div/following-sibling::div/div/div/div/textarea")
	WebElement CardDetails;
	
	@FindBy (xpath = "//div/textarea[@aria-label='List A']/parent::div/following-sibling::div/div/div[2]/div/input[@value='Add card']")
	WebElement AddCard;
	
	@FindBy (xpath = "//div/textarea[@aria-label='List A']/parent::div/following-sibling::div/a")
	WebElement Draggable;
	
	@FindBy (xpath = "//div/textarea[@aria-label='List B']/parent::div/following-sibling::div/a")
	WebElement Droppable;
	
	@FindBy (xpath = "//div/textarea[@aria-label='List B']/parent::div/following-sibling::div/a")
	WebElement Location;
	
	@FindBy (xpath = "//*[@id='header']/div[2]/div[6]")
	WebElement AvatarIcon;
	
	@FindBy (xpath = "//section/div/div/div/div[3]/ul/li/button")
	WebElement LogOutBtn;
	
	public TrelloWorkSpace_Obj(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebElement NewBoard() {
		return NewBoard;
	}
	
	public WebElement NewBoardTitle() {
		return NewBoardTitle;
	}
	
	public WebElement CreateNewBoardBtn() {
		return CreateNewBoardBtn;
	}
	
	public WebElement AddList() {
		return AddList;
	}
	
	public WebElement ListTitle() {
		return ListTitle;
	}
	
	public WebElement AddListBtn() {
		return AddListBtn;
	}
	
	public WebElement Add_A_Card() {
		return Add_A_Card;
	}
	
	public WebElement CardDetails() {
		return CardDetails;
	}
	
	public WebElement AddCard() {
		return AddCard;
	}
	
	public WebElement Draggable() {
		return Draggable;
	}
	
	public WebElement Droppable() {
		return Droppable;
	}

	public WebElement Location() {
		return Location;
	}

	public WebElement AvatarIcon() {
		return AvatarIcon;
	}
	
	public WebElement LogOutBtn() {
		return LogOutBtn;
	}
	
	
	
	

}
