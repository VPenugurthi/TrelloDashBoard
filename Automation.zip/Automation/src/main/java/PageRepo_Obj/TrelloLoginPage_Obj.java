package PageRepo_Obj;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TrelloLoginPage_Obj {
	WebDriver driver;
	
	@FindBy (id = "user")
	WebElement UserID;
	
	@FindBy (id = "password")
	WebElement Password;
	
	@FindBy (id = "login")
	WebElement ContinueBtn;
	
	@FindBy (xpath = "//span[contains(text(),'Log in')]")
	WebElement LoginBtn;
	
	
	
	public TrelloLoginPage_Obj(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebElement UserID() {
		return UserID;		
	}
	
	public WebElement Password() {
		return Password;		
	}
	
	public WebElement ContinueBtn() {
		return ContinueBtn;		
	}
	
	public WebElement LoginBtn() {
		return LoginBtn;
	}

}
