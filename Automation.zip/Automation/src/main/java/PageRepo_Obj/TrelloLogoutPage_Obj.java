package PageRepo_Obj;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TrelloLogoutPage_Obj {
	WebDriver driver;
	
	@FindBy (id = "logout-submit")
	WebElement LogOutConfirmBtn;
	
	
	
	public TrelloLogoutPage_Obj(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebElement LogOutConfirmBtn() {
		return LogOutConfirmBtn;		
	}
		
}
