package Automation;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import Config.LaunchWebDriver;
import PageRepo_Obj.TrelloLoginPage_Obj;
import PageRepo_Obj.TrelloLogoutPage_Obj;
import PageRepo_Obj.TrelloWorkSpace_Obj;

public class LaunchTrello extends LaunchWebDriver {
	@Test
	public void LaunchWebBrowser() throws InterruptedException {
		driver = LaunchBrowser();
		
		// Login Into Trello
		driver.get("https://trello.com/en/login");
		TrelloLoginPage_Obj LoginPage = new TrelloLoginPage_Obj(driver);
		// Enter User Credentials
		LoginPage.UserID().sendKeys("vamsipenugurthi52@gmail.com");
		LoginPage.ContinueBtn().click();
		wait.until(ExpectedConditions.visibilityOf(LoginPage.Password()));
		LoginPage.Password().sendKeys("V@msi010203");
		LoginPage.LoginBtn().click();
		// Access Trello WorkSpace
		TrelloWorkSpace_Obj TWorkSpace = new TrelloWorkSpace_Obj(driver);
		wait.until(ExpectedConditions.visibilityOf(TWorkSpace.NewBoard()));
		// Creating a new board
		TWorkSpace.NewBoard().click();
		TWorkSpace.NewBoardTitle().sendKeys("TWorkSpace");
		TWorkSpace.CreateNewBoardBtn().click();
		wait.until(ExpectedConditions.visibilityOf(TWorkSpace.AddList()));
		// Adding List
		TWorkSpace.AddList().click();
		TWorkSpace.ListTitle().sendKeys("List A");
		TWorkSpace.AddListBtn().click();
		TWorkSpace.ListTitle().sendKeys("List B");
		TWorkSpace.AddListBtn().click();
		// Adding Card
		TWorkSpace.Add_A_Card().click();
		TWorkSpace.CardDetails().click();
		TWorkSpace.CardDetails().sendKeys("Task A");
		Actions action = new Actions(driver);
		action.moveByOffset(0, 0).click().build().perform();
		// Performing Drag And Drop action
		action.dragAndDrop(TWorkSpace.Draggable(), TWorkSpace.Droppable()).build().perform();
		wait.until(ExpectedConditions.visibilityOf(TWorkSpace.Location()));
		Point Coordinates = TWorkSpace.Location().getLocation();
		int XCoordinates = Coordinates.getX();
		int YCoordinates = Coordinates.getY();
        System.out.println("X Coordinates = " + XCoordinates + ", Y Coordinates = " + YCoordinates);
        // Avatar Icon CLick
        TWorkSpace.AvatarIcon().click();
        wait.until(ExpectedConditions.visibilityOf(TWorkSpace.LogOutBtn()));
        // LogOut Button Click
        TWorkSpace.LogOutBtn().click();
        TrelloLogoutPage_Obj LogOut = new TrelloLogoutPage_Obj(driver);
        LogOut.LogOutConfirmBtn().click();
        driver.close();

		
		
		
		
	}

}
